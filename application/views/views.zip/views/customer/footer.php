<footer class="main-footer">
  <strong>Copyright &copy; 2015 <a href="">Blank Studio</a>.</strong> All rights reserved.
</footer>
